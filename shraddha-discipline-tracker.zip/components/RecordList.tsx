import React from 'react';
import { DisciplineRecord } from '../types';
import RecordCard from './RecordCard';
import * as XLSX from 'xlsx';

interface RecordListProps {
  records: DisciplineRecord[];
}

const RecordList: React.FC<RecordListProps> = ({ records }) => {

  const handleExportToExcel = () => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weeklyRecords = records.filter(record => {
      const recordDate = new Date(record.date);
      return recordDate >= oneWeekAgo;
    });

    if (weeklyRecords.length === 0) {
      alert("No records found in the last 7 days to export.");
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(weeklyRecords);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Weekly Discipline Report");
    
    const today = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `Shraddha_Discipline_Report_Weekly_${today}.xlsx`);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-6">
            <h2 className="text-xl font-bold text-slate-700 mb-4 sm:mb-0">Discipline Records</h2>
            <button
              onClick={handleExportToExcel}
              className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors"
              aria-label="Download weekly discipline report as Excel"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Download Weekly Report
            </button>
        </div>
        {records.length === 0 ? (
            <div className="text-center py-10 text-slate-500">
                <p>No records found. Add a new record to get started.</p>
            </div>
        ) : (
            <div className="space-y-4">
                {records.map((record) => (
                    <RecordCard key={record.id} record={record} />
                ))}
            </div>
        )}
    </div>
  );
};

export default RecordList;