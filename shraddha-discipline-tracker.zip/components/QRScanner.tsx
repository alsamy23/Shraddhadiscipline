import React, { useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

interface QRScannerProps {
  onScanSuccess: (decodedText: string) => void;
  onClose: () => void;
}

const QRScanner: React.FC<QRScannerProps> = ({ onScanSuccess, onClose }) => {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    // Prevent multiple initializations
    if (!scannerRef.current) {
      const scanner = new Html5QrcodeScanner(
        'qr-reader', 
        { 
          fps: 10, 
          qrbox: { width: 250, height: 250 },
          rememberLastUsedCamera: true,
        },
        /* verbose= */ false
      );

      const handleSuccess = (decodedText: string) => {
        // Cleanup is handled in the return function of useEffect
        onScanSuccess(decodedText);
      };

      const handleError = (error: string) => {
        // This callback is called frequently, so keep it minimal.
        // console.warn(`QR error = ${error}`);
      };

      scanner.render(handleSuccess, handleError);
      scannerRef.current = scanner;
    }

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(error => {
          // This can happen if the component unmounts before scanner is fully initialized.
          console.error("Failed to clear html5-qrcode-scanner.", error);
        });
        scannerRef.current = null;
      }
    };
  }, [onScanSuccess]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex flex-col items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl p-4 md:p-6 w-full max-w-md mx-4">
        <h2 className="text-lg font-bold text-center text-slate-700 mb-4">Scan Student QR Code</h2>
        <div id="qr-reader" className="w-full"></div>
        <button
          onClick={onClose}
          className="mt-4 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-slate-600 hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500 transition-colors"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};

export default QRScanner;
