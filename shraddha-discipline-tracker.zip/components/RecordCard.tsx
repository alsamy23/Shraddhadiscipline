
import React, { useState, useCallback } from 'react';
import { DisciplineRecord, InfractionType } from '../types';
import generateDisciplineNote from '../services/geminiService';

interface RecordCardProps {
  record: DisciplineRecord;
}

const InfractionIcon: React.FC<{ type: InfractionType }> = ({ type }) => {
    const iconColor = "text-slate-500";
    const iconSize = "h-6 w-6";
    switch(type) {
        case InfractionType.HAIR_CUT:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M14.121 14.121L15 15m2.879-2.879l-1.414-1.414m0 0L10.5 3.5v7m-1.414 4.5l-4.243 4.243-1.414-1.414 4.243-4.243m-2.829-2.829l-4.243-4.243 1.414-1.414 4.243 4.243" /></svg>;
        case InfractionType.UNIFORM:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 11V7a4 4 0 118 0v4M5 9h14l1 12H4L5 9z" /></svg>;
        case InfractionType.LATE_COMER:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
        case InfractionType.ID_CARD:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0z" /></svg>;
        default:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" /></svg>;
    }
};

const LoadingSpinner: React.FC = () => (
    <div className="flex items-center space-x-2">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-slate-500"></div>
        <span className="text-sm text-slate-500">Generating...</span>
    </div>
);

const RecordCard: React.FC<RecordCardProps> = ({ record }) => {
  const [generatedNote, setGeneratedNote] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleGenerateNote = useCallback(async () => {
    setIsLoading(true);
    setGeneratedNote('');
    const note = await generateDisciplineNote(record);
    setGeneratedNote(note);
    setIsLoading(false);
  }, [record]);

  return (
    <div className="border border-slate-200 rounded-lg p-4 transition-shadow hover:shadow-md">
      <div className="flex flex-col sm:flex-row justify-between sm:items-start">
        <div>
          <h3 className="text-lg font-semibold text-slate-800">{record.studentName}</h3>
          <p className="text-sm text-slate-500">Grade: {record.grade}</p>
          <p className="text-sm text-slate-500">Date: {record.date}</p>
        </div>
        <div className="mt-2 sm:mt-0 flex items-center space-x-2 bg-slate-100 px-3 py-1 rounded-full">
            <InfractionIcon type={record.infractionType} />
            <span className="text-sm font-medium text-slate-700">{record.infractionType}</span>
        </div>
      </div>
      <p className="mt-3 text-slate-600 text-sm">{record.notes}</p>
      
      <div className="mt-4">
        <button
          onClick={handleGenerateNote}
          disabled={isLoading}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-indigo-500 hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? 'Generating...' : 'Generate Parent Note'}
        </button>
      </div>

      {isLoading && <div className="mt-4"><LoadingSpinner /></div>}
      
      {generatedNote && (
        <div className="mt-4 p-4 bg-slate-50 rounded-md border border-slate-200">
            <h4 className="font-semibold text-sm text-slate-700 mb-2">Generated Note:</h4>
            <p className="text-sm text-slate-600 whitespace-pre-wrap">{generatedNote}</p>
        </div>
      )}
    </div>
  );
};

export default RecordCard;
