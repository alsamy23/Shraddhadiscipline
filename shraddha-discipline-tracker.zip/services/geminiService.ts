
import { GoogleGenAI } from "@google/genai";
import { DisciplineRecord } from '../types';

const generateDisciplineNote = async (record: DisciplineRecord): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API key not configured. Please set the API_KEY environment variable.";
  }
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      You are an assistant for a school principal. Based on the following student discipline issue, write a polite and professional note to be sent to the parents.
      The note should be firm but respectful, explaining the issue and suggesting a conversation to resolve it. Keep it concise, around 3-4 sentences.
      
      Student Name: ${record.studentName}
      Grade: ${record.grade}
      Infraction Type: ${record.infractionType}
      Date: ${record.date}
      Details: ${record.notes}

      Address the parents as "Dear Parent/Guardian of ${record.studentName}," and sign off with "Sincerely, Shraddha School Administration".
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Error generating discipline note:", error);
    return "Failed to generate note. Please check the console for more details.";
  }
};

export default generateDisciplineNote;
